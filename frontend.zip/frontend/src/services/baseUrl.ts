const baseUrl = process.env.REACT_APP_API_ENDPOINT + "/api/v1/";
console.log("baseurl is", baseUrl);
export default baseUrl;
