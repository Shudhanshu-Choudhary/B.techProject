import React from "react";
import Posts from "../../pages/Posts";

const PostView = ()=>{
  return(
    <div className = 'apw-main-container'>
      <Posts/>
    </div>
  );
};
export default PostView;
